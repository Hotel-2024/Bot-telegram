# Msg-to-telegram-from-HTML-form
1) Create your tlg bot using @BotFather
2) Press /start
3) After this u'll get your's bot token
4) Create chat (u must do it, because u'll get sms)
5) Open your browser and input  https://api.telegram.org/botXXXXXXXXXXXXXXXXXXXXXXX/getUpdates , where XXXXXXXXXXXXXXXXXXXXXXX - token, what u've got from @BotFather
6) Input this token and chat id in php file
7) DONE! 

p.s. src: https://habr.com/ru/post/348332/
